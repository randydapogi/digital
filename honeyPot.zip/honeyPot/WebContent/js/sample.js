function sampleAlert() {
	$.ajax({ 
	    url: "update", 
	    type: 'GET', 
	    success: function(data) {
	    	alert(data);
	    	$("#sample").text(data).trigger("create");
	    },
	    error:function(data,status,er) { 
	        //alert("error: "+data+" status: "+status+" er:"+er);
	    	if (er=='Forbidden') {
	        	window.location.href = "403";
	        	//window.location.reload();
	        } else {
	        	alert("error: "+data+" status: "+status+" er:"+er);
	        }
	    }
	});	
};